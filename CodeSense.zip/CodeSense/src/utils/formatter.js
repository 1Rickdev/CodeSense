/**
 * Formatter - Formats analysis results for different outputs
 */

class Formatter {
  constructor(options = {}) {
    this.options = {
      format: options.format || 'human',
      colors: options.colors !== false,
      ...options
    };
  }

  /**
   * Format analysis results
   * @param {Object} results - Analysis results
   * @returns {string} Formatted output
   */
  format(results) {
    switch (this.options.format) {
      case 'json':
        return this._formatJson(results);
      case 'markdown':
        return this._formatMarkdown(results);
      case 'csv':
        return this._formatCsv(results);
      case 'html':
        return this._formatHtml(results);
      default:
        return this._formatHuman(results);
    }
  }

  /**
   * Format as human-readable text
   * @param {Object} results - Analysis results
   * @returns {string} Formatted text
   */
  _formatHuman(results) {
    let output = '';
    
    output += `File: ${results.file}\n`;
    output += `Quality Score: ${results.score}/100\n\n`;
    
    if (results.metrics) {
      output += 'Metrics:\n';
      output += `  Cyclomatic Complexity: ${results.metrics.complexity?.cyclomatic || 'N/A'}\n`;
      output += `  Cognitive Complexity: ${results.metrics.complexity?.cognitive || 'N/A'}\n`;
      output += `  Maintainability: ${results.metrics.complexity?.maintainability || 'N/A'}/100\n`;
    }
    
    output += `\nIssues Found: ${results.issues?.length || 0}\n`;
    
    if (results.issues && results.issues.length > 0) {
      results.issues.forEach((issue, index) => {
        output += `\n${index + 1}. [${issue.severity || 'UNKNOWN'}] ${issue.type || 'ISSUE'}\n`;
        output += `   Message: ${issue.message}\n`;
        
        if (issue.suggestion) {
          output += `   Suggestion: ${issue.suggestion}\n`;
        }
        
        if (issue.location) {
          output += `   Location: Line ${issue.location.start?.line || '?'}\n`;
        }
      });
    }
    
    return output;
  }

  /**
   * Format as JSON
   * @param {Object} results - Analysis results
   * @returns {string} JSON string
   */
  _formatJson(results) {
    return JSON.stringify(results, null, 2);
  }

  /**
   * Format as Markdown
   * @param {Object} results - Analysis results
   * @returns {string} Markdown string
   */
  _formatMarkdown(results) {
    let output = `# Code Analysis Report\n\n`;
    
    output += `**File:** \`${results.file}\`\n`;
    output += `**Quality Score:** ${results.score}/100\n`;
    output += `**Analysis Time:** ${new Date(results.timestamp).toLocaleString()}\n\n`;
    
    if (results.metrics) {
      output += `## Metrics\n\n`;
      output += `| Metric | Value |\n`;
      output += `|--------|-------|\n`;
      output += `| Cyclomatic Complexity | ${results.metrics.complexity?.cyclomatic || 'N/A'} |\n`;
      output += `| Cognitive Complexity | ${results.metrics.complexity?.cognitive || 'N/A'} |\n`;
      output += `| Maintainability | ${results.metrics.complexity?.maintainability || 'N/A'}/100 |\n`;
      output += `| Functions | ${results.metrics.volume?.functions || 0} |\n`;
      output += `| Loops | ${results.metrics.volume?.loops || 0} |\n\n`;
    }
    
    const issueCount = results.issues?.length || 0;
    output += `## Issues (${issueCount})\n\n`;
    
    if (issueCount > 0) {
      output += `| Severity | Type | Message | Suggestion |\n`;
      output += `|----------|------|---------|------------|\n`;
      
      results.issues.forEach(issue => {
        const severity = issue.severity || 'UNKNOWN';
        const type = issue.type || 'ISSUE';
        const message = issue.message?.replace(/\|/g, '\\|') || '';
        const suggestion = issue.suggestion?.replace(/\|/g, '\\|') || '';
        
        output += `| ${severity} | ${type} | ${message} | ${suggestion} |\n`;
      });
    } else {
      output += `✅ No issues found!\n`;
    }
    
    return output;
  }

  /**
   * Format as CSV
   * @param {Object} results - Analysis results
   * @returns {string} CSV string
   */
  _formatCsv(results) {
    let output = 'File,Score,Timestamp,IssueCount\n';
    output += `${results.file},${results.score},${results.timestamp},${results.issues?.length || 0}\n\n`;
    
    if (results.issues && results.issues.length > 0) {
      output += 'Severity,Type,Message,Suggestion\n';
      results.issues.forEach(issue => {
        const severity = issue.severity || 'UNKNOWN';
        const type = issue.type || 'ISSUE';
        const message = `"${(issue.message || '').replace(/"/g, '""')}"`;
        const suggestion = `"${(issue.suggestion || '').replace(/"/g, '""')}"`;
        
        output += `${severity},${type},${message},${suggestion}\n`;
      });
    }
    
    return output;
  }

  /**
   * Format as HTML
   * @param {Object} results - Analysis results
   * @returns {string} HTML string
   */
  _formatHtml(results) {
    const scoreColor = results.score >= 80 ? 'green' : results.score >= 60 ? 'orange' : 'red';
    
    return `
<!DOCTYPE html>
<html>
<head>
    <title>Code Analysis Report - ${results.file}</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 40px; }
        .header { background: #f5f5f5; padding: 20px; border-radius: 5px; }
        .score { font-size: 48px; font-weight: bold; color: ${scoreColor}; }
        .metric { margin: 10px 0; }
        .issue { border-left: 4px solid #ddd; padding: 10px; margin: 10px 0; }
        .critical { border-color: #ff4444; }
        .high { border-color: #ff8800; }
        .medium { border-color: #ffbb33; }
        .low { border-color: #00C851; }
        table { border-collapse: collapse; width: 100%; }
        th, td { text-align: left; padding: 8px; border-bottom: 1px solid #ddd; }
    </style>
</head>
<body>
    <div class="header">
        <h1>Code Analysis Report</h1>
        <p><strong>File:</strong> ${results.file}</p>
        <p><strong>Analyzed:</strong> ${new Date(results.timestamp).toLocaleString()}</p>
        <div class="score">${results.score}/100</div>
    </div>
    
    ${results.metrics ? `
    <h2>Metrics</h2>
    <div class="metric">
        <strong>Cyclomatic Complexity:</strong> ${results.metrics.complexity?.cyclomatic || 'N/A'}<br>
        <strong>Cognitive Complexity:</strong> ${results.metrics.complexity?.cognitive || 'N/A'}<br>
        <strong>Maintainability:</strong> ${results.metrics.complexity?.maintainability || 'N/A'}/100
    </div>
    ` : ''}
    
    <h2>Issues (${results.issues?.length || 0})</h2>
    ${results.issues && results.issues.length > 0 ? `
    <table>
        <tr>
            <th>Severity</th>
            <th>Type</th>
            <th>Message</th>
            <th>Suggestion</th>
        </tr>
        ${results.issues.map(issue => `
        <tr>
            <td><span class="severity ${issue.severity?.toLowerCase() || 'unknown'}">${issue.severity || 'UNKNOWN'}</span></td>
            <td>${issue.type || 'ISSUE'}</td>
            <td>${issue.message || ''}</td>
            <td>${issue.suggestion || ''}</td>
        </tr>
        `).join('')}
    </table>
    ` : '<p>✅ No issues found!</p>'}
</body>
</html>
    `;
  }
}

module.exports = Formatter;
/**
 * Logger - Professional logging utility with colors and formatting
 */

const chalk = require('chalk');

class Logger {
  constructor(options = {}) {
    this.level = options.level || 'info';
    this.useColors = options.colors !== false;
  }

  // Log levels
  static LEVELS = {
    ERROR: 0,
    WARN: 1,
    INFO: 2,
    DEBUG: 3
  };

  /**
   * Log error message
   * @param {string} message - Error message
   * @param {Error} [error] - Optional error object
   */
  error(message, error = null) {
    if (this._shouldLog(Logger.LEVELS.ERROR)) {
      const prefix = this.useColors ? chalk.red('✗ ERROR') : '[ERROR]';
      console.error(`${prefix} ${message}`);
      
      if (error && error.stack) {
        console.error(this.useColors ? chalk.gray(error.stack) : error.stack);
      }
    }
  }

  /**
   * Log warning message
   * @param {string} message - Warning message
   */
  warn(message) {
    if (this._shouldLog(Logger.LEVELS.WARN)) {
      const prefix = this.useColors ? chalk.yellow('⚠ WARN') : '[WARN]';
      console.warn(`${prefix} ${message}`);
    }
  }

  /**
   * Log info message
   * @param {string} message - Info message
   */
  info(message) {
    if (this._shouldLog(Logger.LEVELS.INFO)) {
      const prefix = this.useColors ? chalk.blue('ℹ INFO') : '[INFO]';
      console.log(`${prefix} ${message}`);
    }
  }

  /**
   * Log success message
   * @param {string} message - Success message
   */
  success(message) {
    if (this._shouldLog(Logger.LEVELS.INFO)) {
      const prefix = this.useColors ? chalk.green('✓ SUCCESS') : '[SUCCESS]';
      console.log(`${prefix} ${message}`);
    }
  }

  /**
   * Log debug message
   * @param {string} message - Debug message
   * @param {any} [data] - Optional data to log
   */
  debug(message, data = null) {
    if (this._shouldLog(Logger.LEVELS.DEBUG)) {
      const prefix = this.useColors ? chalk.gray('🔍 DEBUG') : '[DEBUG]';
      console.log(`${prefix} ${message}`);
      
      if (data !== null) {
        console.log(this.useColors ? chalk.gray(JSON.stringify(data, null, 2)) : data);
      }
    }
  }

  /**
   * Display analysis results
   * @param {Object} results - Analysis results
   */
  displayResults(results) {
    console.log('\n' + '='.repeat(60));
    
    const title = this.useColors 
      ? chalk.bold.cyan('📊 CODE SENSE ANALYSIS REPORT')
      : 'CODE SENSE ANALYSIS REPORT';
    
    console.log(title);
    console.log('='.repeat(60));
    
    // File info
    console.log(`📁 File: ${results.file}`);
    console.log(`⏰ Analyzed: ${new Date(results.timestamp).toLocaleTimeString()}`);
    console.log('');
    
    // Score with color
    let scoreColor = chalk.green;
    if (results.score < 70) scoreColor = chalk.yellow;
    if (results.score < 50) scoreColor = chalk.red;
    
    console.log(`🏆 Quality Score: ${scoreColor.bold(`${results.score}/100`)}`);
    
    // Metrics
    if (results.metrics && results.metrics.complexity) {
      console.log('\n📈 Metrics:');
      console.log(`  Cyclomatic Complexity: ${results.metrics.complexity.cyclomatic}`);
      console.log(`  Cognitive Complexity: ${results.metrics.complexity.cognitive}`);
      console.log(`  Maintainability: ${results.metrics.complexity.maintainability}/100`);
    }
    
    // Issues summary
    const issueCount = results.issues?.length || 0;
    console.log(`\n📝 Issues Found: ${issueCount}`);
    
    if (issueCount > 0) {
      // Group by severity
      const bySeverity = results.issues.reduce((acc, issue) => {
        const severity = issue.severity || 'UNKNOWN';
        acc[severity] = (acc[severity] || 0) + 1;
        return acc;
      }, {});
      
      Object.entries(bySeverity).forEach(([severity, count]) => {
        let severityIcon = '○';
        let severityColor = chalk.white;
        
        switch (severity) {
          case 'CRITICAL': severityIcon = '🔴'; severityColor = chalk.red; break;
          case 'HIGH': severityIcon = '🟠'; severityColor = chalk.yellow; break;
          case 'MEDIUM': severityIcon = '🟡'; severityColor = chalk.yellow; break;
          case 'LOW': severityIcon = '🔵'; severityColor = chalk.blue; break;
        }
        
        console.log(`  ${severityIcon} ${severityColor(severity)}: ${count}`);
      });
      
      // Show top issues
      console.log('\n🚨 Top Issues:');
      results.issues.slice(0, 5).forEach((issue, index) => {
        let bullet = this.useColors ? chalk.gray(`${index + 1}.`) : `${index + 1}.`;
        console.log(`  ${bullet} ${issue.message}`);
        
        if (issue.suggestion) {
          console.log(`     ${chalk.gray('💡 ' + issue.suggestion)}`);
        }
      });
      
      if (results.issues.length > 5) {
        console.log(chalk.gray(`  ... and ${results.issues.length - 5} more issues`));
      }
    } else {
      console.log(chalk.green('\n✅ No issues found! Code looks great!'));
    }
    
    console.log('\n' + '='.repeat(60));
  }

  /**
   * Display project summary
   * @param {Object} summary - Project analysis summary
   */
  displayProjectSummary(summary) {
    console.log('\n' + '='.repeat(60));
    console.log(chalk.bold.cyan('📊 PROJECT ANALYSIS SUMMARY'));
    console.log('='.repeat(60));
    
    console.log(`📁 Total Files: ${summary.totalFiles}`);
    console.log(`✅ Successfully Analyzed: ${summary.analyzedFiles}`);
    console.log(`❌ Failed: ${summary.failedFiles}`);
    console.log(`📝 Total Issues: ${summary.totalIssues}`);
    console.log(`🏆 Average Quality Score: ${summary.averageScore.toFixed(1)}/100`);
    
    if (summary.topIssues && summary.topIssues.length > 0) {
      console.log('\n🚨 Most Common Issues:');
      summary.topIssues.forEach((issue, index) => {
        console.log(`  ${index + 1}. ${issue.type}: ${issue.count} occurrences`);
      });
    }
    
    console.log('\n' + '='.repeat(60));
  }

  /**
   * Display loading spinner
   * @param {string} message - Loading message
   * @returns {Object} Spinner control object
   */
  createSpinner(message) {
    const frames = this.useColors 
      ? ['⠋', '⠙', '⠹', '⠸', '⠼', '⠴', '⠦', '⠧', '⠇', '⠏']
      : ['.', '..', '...'];
    
    let frameIndex = 0;
    let intervalId = null;
    
    const update = () => {
      const frame = frames[frameIndex % frames.length];
      const prefix = this.useColors ? chalk.blue(frame) : frame;
      process.stdout.write(`\r${prefix} ${message}`);
      frameIndex++;
    };
    
    return {
      start: () => {
        intervalId = setInterval(update, 100);
        return this;
      },
      stop: (successMessage = null) => {
        if (intervalId) {
          clearInterval(intervalId);
          intervalId = null;
          process.stdout.write('\r' + ' '.repeat(message.length + 10) + '\r');
          
          if (successMessage) {
            this.success(successMessage);
          }
        }
        return this;
      },
      updateMessage: (newMessage) => {
        message = newMessage;
        return this;
      }
    };
  }

  // Private method to check log level
  _shouldLog(level) {
    const currentLevel = Logger.LEVELS[this.level.toUpperCase()] || Logger.LEVELS.INFO;
    return level <= currentLevel;
  }
}

module.exports = Logger;
/**
 * Code Analyzer - Main analysis engine
 * Orchestrates parsing, pattern detection, and rule application
 */

const ASTParser = require('./ast-parser.js');
const RuleEngine = require('./rules.js');

class CodeAnalyzer {
  constructor(config = {}) {
    this.parser = new ASTParser(config.parserOptions);
    this.rules = new RuleEngine(config.ruleOptions);
    this.config = config;
  }

  /**
   * Analyze a JavaScript file
   * @param {string} filePath - Path to the file
   * @param {string} sourceCode - JavaScript source code
   * @returns {Object} Analysis results
   */
  async analyzeFile(filePath, sourceCode) {
    const results = {
      file: filePath,
      patterns: null,
      issues: [],
      metrics: {},
      score: 100,
      timestamp: new Date().toISOString()
    };

    try {
      // Step 1: Parse code into AST
      const ast = this.parser.parse(sourceCode, filePath);
      
      // Step 2: Extract patterns and metrics
      results.patterns = this.parser.extractPatterns(ast);
      
      // Step 3: Detect code smells
      const smells = this.parser.detectCodeSmells(ast);
      results.issues.push(...smells);
      
      // Step 4: Apply rule engine
      const ruleIssues = this.rules.apply(ast, results.patterns);
      results.issues.push(...ruleIssues);
      
      // Step 5: Calculate metrics
      results.metrics = this.calculateMetrics(results.patterns, results.issues);
      
      // Step 6: Calculate quality score
      results.score = this.calculateQualityScore(results.metrics, results.issues);
      
      results.success = true;
      
    } catch (error) {
      results.success = false;
      results.error = error.message;
      results.issues.push({
        type: 'PARSER_ERROR',
        severity: 'CRITICAL',
        message: `Failed to analyze file: ${error.message}`
      });
    }

    return results;
  }

  /**
   * Calculate code metrics
   * @param {Object} patterns - Extracted code patterns
   * @param {Array} issues - Detected issues
   * @returns {Object} Calculated metrics
   */
  calculateMetrics(patterns, issues) {
    if (!patterns) return {};
    
    return {
      complexity: {
        cyclomatic: patterns.complexity.cyclomatic,
        cognitive: Math.round(patterns.complexity.cognitive),
        maintainability: this.calculateMaintainability(patterns)
      },
      volume: {
        functions: patterns.functions.length,
        loops: patterns.loops.length,
        conditionals: patterns.conditionals.length,
        asyncOperations: patterns.asyncOperations.length
      },
      quality: {
        issuesBySeverity: this.groupIssuesBySeverity(issues),
        issueCount: issues.length
      }
    };
  }

  /**
   * Calculate maintainability index
   * @param {Object} patterns - Extracted code patterns
   * @returns {number} Maintainability score (0-100)
   */
  calculateMaintainability(patterns) {
    const baseScore = 100;
    
    // Penalize complexity
    let penalty = 0;
    penalty += patterns.complexity.cyclomatic * 0.5;
    penalty += patterns.complexity.cognitive * 0.2;
    penalty += patterns.loops.length * 1;
    penalty += patterns.conditionals.length * 0.5;
    
    const score = Math.max(0, Math.min(100, baseScore - penalty));
    return Math.round(score);
  }

  /**
   * Group issues by severity
   * @param {Array} issues - Detected issues
   * @returns {Object} Issues grouped by severity
   */
  groupIssuesBySeverity(issues) {
    return issues.reduce((groups, issue) => {
      const severity = issue.severity || 'UNKNOWN';
      groups[severity] = (groups[severity] || 0) + 1;
      return groups;
    }, {});
  }

  /**
   * Calculate overall quality score
   * @param {Object} metrics - Code metrics
   * @param {Array} issues - Detected issues
   * @returns {number} Quality score (0-100)
   */
  calculateQualityScore(metrics, issues) {
    let score = 100;
    
    // Penalize for issues
    issues.forEach(issue => {
      switch (issue.severity) {
        case 'CRITICAL': score -= 15; break;
        case 'HIGH': score -= 10; break;
        case 'MEDIUM': score -= 5; break;
        case 'LOW': score -= 2; break;
      }
    });
    
    // Consider complexity
    if (metrics.complexity) {
      if (metrics.complexity.cyclomatic > 15) score -= 10;
      if (metrics.complexity.cognitive > 20) score -= 10;
      if (metrics.complexity.maintainability < 60) score -= 5;
    }
    
    return Math.max(0, Math.min(100, Math.round(score)));
  }

  /**
   * Analyze multiple files
   * @param {Array} files - Array of file paths
   * @returns {Object} Combined analysis results
   */
  async analyzeProject(files) {
    const results = {
      files: [],
      summary: {
        totalFiles: 0,
        analyzedFiles: 0,
        failedFiles: 0,
        totalIssues: 0,
        averageScore: 0
      },
      timestamp: new Date().toISOString()
    };

    // This would be implemented to analyze multiple files
    return results;
  }
}

module.exports = CodeAnalyzer;
/**
 * AST Parser - Converts JavaScript code into Abstract Syntax Tree
 * Uses Acorn parser for reliable AST generation
 */

const acorn = require('acorn');
const walk = require('acorn-walk');

class ASTParser {
  constructor(options = {}) {
    this.options = {
      ecmaVersion: 'latest',
      sourceType: 'module',
      locations: true,
      ...options
    };
  }

  /**
   * Parse JavaScript code into AST
   * @param {string} code - JavaScript source code
   * @param {string} filename - Source filename for error reporting
   * @returns {Object} Abstract Syntax Tree
   */
  parse(code, filename = 'anonymous') {
    try {
      return acorn.parse(code, {
        ...this.options,
        sourceFile: filename
      });
    } catch (error) {
      throw new SyntaxError(`Failed to parse ${filename}: ${error.message}`);
    }
  }

  /**
   * Extract code patterns and metrics from AST
   * @param {Object} ast - Abstract Syntax Tree
   * @returns {Object} Extracted patterns and metrics
   */
  extractPatterns(ast) {
    const patterns = {
      loops: [],
      conditionals: [],
      functions: [],
      asyncOperations: [],
      variables: [],
      complexity: {
        cyclomatic: 1,
        cognitive: 0
      }
    };

    walk.simple(ast, {
      // Count loops
      ForStatement(node) {
        patterns.loops.push({
          type: 'for',
          location: node.loc
        });
        patterns.complexity.cyclomatic++;
      },
      
      WhileStatement(node) {
        patterns.loops.push({
          type: 'while',
          location: node.loc
        });
        patterns.complexity.cyclomatic++;
      },
      
      // Count conditionals
      IfStatement(node) {
        patterns.conditionals.push({
          type: 'if',
          location: node.loc,
          hasElse: !!node.alternate
        });
        patterns.complexity.cyclomatic++;
      },
      
      SwitchStatement(node) {
        patterns.conditionals.push({
          type: 'switch',
          location: node.loc,
          cases: node.cases.length
        });
        patterns.complexity.cyclomatic += node.cases.length;
      },
      
      // Track functions
      FunctionDeclaration(node) {
        patterns.functions.push({
          name: node.id?.name || 'anonymous',
          type: 'declaration',
          location: node.loc
        });
      },
      
      // Track async operations
      AwaitExpression(node) {
        patterns.asyncOperations.push({
          type: 'await',
          location: node.loc
        });
      },
      
      // Track variable declarations
      VariableDeclaration(node) {
        node.declarations.forEach(decl => {
          if (decl.id.type === 'Identifier') {
            patterns.variables.push({
              name: decl.id.name,
              kind: node.kind,
              location: decl.loc
            });
          }
        });
      }
    });

    // Calculate cognitive complexity (simplified)
    patterns.complexity.cognitive = 
      (patterns.loops.length * 2) + 
      (patterns.conditionals.length * 1.5) +
      (patterns.asyncOperations.length * 1.2);

    return patterns;
  }

  /**
   * Check for specific code patterns
   * @param {Object} ast - Abstract Syntax Tree
   * @returns {Array} Detected code smells
   */
  detectCodeSmells(ast) {
    const smells = [];

    walk.simple(ast, {
      // Nested loops
      ForStatement(node) {
        walk.simple(node.body, {
          ForStatement() {
            smells.push({
              type: 'NESTED_LOOP',
              severity: 'MEDIUM',
              message: 'Nested loop detected - O(n²) complexity',
              suggestion: 'Consider optimizing algorithm or using caching'
            });
          }
        });
      },

      // Deep callback nesting
      CallExpression(node) {
        let depth = 0;
        let current = node;
        
        while (current && current.type === 'CallExpression') {
          depth++;
          current = current.arguments.find(arg => arg.type === 'CallExpression');
        }
        
        if (depth > 2) {
          smells.push({
            type: 'CALLBACK_HELL',
            severity: 'HIGH',
            message: `Deep callback nesting (depth: ${depth})`,
            suggestion: 'Refactor using async/await or Promises'
          });
        }
      },

      // Long function
      FunctionDeclaration(node) {
        if (node.body.body && node.body.body.length > 50) {
          smells.push({
            type: 'LONG_FUNCTION',
            severity: 'LOW',
            message: 'Function is very long (50+ statements)',
            suggestion: 'Split into smaller, focused functions'
          });
        }
      }
    });

    return smells;
  }
}

module.exports = ASTParser;
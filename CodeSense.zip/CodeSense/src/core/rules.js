/**
 * Rule Engine - Applies analysis rules to code
 */

class RuleEngine {
  constructor(options = {}) {
    this.rules = this.initializeRules(options);
  }

  initializeRules(options) {
    return [
      // Performance rules
      {
        id: 'no-nested-loops',
        name: 'Avoid Nested Loops',
        category: 'PERFORMANCE',
        condition: (patterns) => {
          // Check for nested loops
          return patterns.loops.length > 1;
        },
        message: 'Multiple loops may indicate O(n²) complexity',
        suggestion: 'Consider optimizing with hash maps or caching',
        severity: 'MEDIUM'
      },
      {
        id: 'sequential-async',
        name: 'Avoid Sequential Async',
        category: 'PERFORMANCE',
        condition: (patterns) => patterns.asyncOperations.length > 2,
        message: 'Sequential async operations can be slow',
        suggestion: 'Use Promise.all() for parallel execution',
        severity: 'LOW'
      },

      // Complexity rules
      {
        id: 'high-cyclomatic',
        name: 'High Cyclomatic Complexity',
        category: 'COMPLEXITY',
        condition: (patterns) => patterns.complexity.cyclomatic > 10,
        message: 'High cyclomatic complexity makes code hard to test',
        suggestion: 'Break down complex functions into smaller ones',
        severity: 'MEDIUM'
      },

      // Best practices
      {
        id: 'function-length',
        name: 'Function Too Long',
        category: 'MAINTAINABILITY',
        condition: (patterns) => {
          // Simplified: if many statements in one function
          return false; // Would be calculated from AST
        },
        message: 'Long functions are hard to maintain',
        suggestion: 'Keep functions under 20 lines',
        severity: 'LOW'
      },

      // Security rules
      {
        id: 'eval-usage',
        name: 'Avoid eval()',
        category: 'SECURITY',
        condition: (ast) => {
          // Would search for eval calls in AST
          return false;
        },
        message: 'eval() can lead to code injection',
        suggestion: 'Use JSON.parse() or Function constructor',
        severity: 'HIGH'
      }
    ];
  }

  /**
   * Apply all rules to code
   * @param {Object} ast - Abstract Syntax Tree
   * @param {Object} patterns - Extracted patterns
   * @returns {Array} Detected rule violations
   */
  apply(ast, patterns) {
    const violations = [];

    this.rules.forEach(rule => {
      try {
        const conditionMet = rule.condition(patterns, ast);
        
        if (conditionMet) {
          violations.push({
            type: rule.id,
            category: rule.category,
            severity: rule.severity,
            message: rule.message,
            suggestion: rule.suggestion
          });
        }
      } catch (error) {
        // Skip rules that fail
        console.warn(`Rule ${rule.id} failed: ${error.message}`);
      }
    });

    return violations;
  }

  /**
   * Add custom rule
   * @param {Object} rule - Rule definition
   */
  addRule(rule) {
    this.rules.push({
      id: rule.id || `custom-${Date.now()}`,
      ...rule
    });
  }

  /**
   * Remove rule by ID
   * @param {string} ruleId - Rule identifier
   */
  removeRule(ruleId) {
    this.rules = this.rules.filter(rule => rule.id !== ruleId);
  }
}

module.exports = RuleEngine;
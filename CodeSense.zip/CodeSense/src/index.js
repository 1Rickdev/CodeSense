/**
 * Code Sense - Main Module Export
 * Provides programmatic access to all Code Sense functionality
 */

const CodeAnalyzer = require('./core/analyzer.js');
const ASTParser = require('./core/ast-parser.js');
const RuleEngine = require('./core/rules.js');
const Logger = require('./utils/logger.js');
const Formatter = require('./utils/formatter.js');

/**
 * Create a new Code Sense analyzer instance
 * @param {Object} config - Configuration options
 * @returns {CodeAnalyzer} Analyzer instance
 */
function createAnalyzer(config = {}) {
  return new CodeAnalyzer(config);
}

/**
 * Create a new AST parser instance
 * @param {Object} options - Parser options
 * @returns {ASTParser} Parser instance
 */
function createParser(options = {}) {
  return new ASTParser(options);
}

/**
 * Create a new rule engine
 * @param {Object} options - Rule engine options
 * @returns {RuleEngine} Rule engine instance
 */
function createRuleEngine(options = {}) {
  return new RuleEngine(options);
}

/**
 * Create a new logger
 * @param {Object} options - Logger options
 * @returns {Logger} Logger instance
 */
function createLogger(options = {}) {
  return new Logger(options);
}

/**
 * Create a new formatter
 * @param {Object} options - Formatter options
 * @returns {Formatter} Formatter instance
 */
function createFormatter(options = {}) {
  return new Formatter(options);
}

/**
 * Analyze a JavaScript file
 * @param {string} filePath - Path to the file
 * @param {string} sourceCode - JavaScript source code
 * @param {Object} options - Analysis options
 * @returns {Promise<Object>} Analysis results
 */
async function analyze(filePath, sourceCode, options = {}) {
  const analyzer = createAnalyzer(options);
  return await analyzer.analyzeFile(filePath, sourceCode);
}

/**
 * Analyze multiple files in a project
 * @param {Array<string>} filePaths - Array of file paths
 * @param {Object} options - Analysis options
 * @returns {Promise<Object>} Project analysis results
 */
async function analyzeProject(filePaths, options = {}) {
  const analyzer = createAnalyzer(options);
  return await analyzer.analyzeProject(filePaths);
}

// Export everything
module.exports = {
  // Main classes
  CodeAnalyzer,
  ASTParser,
  RuleEngine,
  Logger,
  Formatter,
  
  // Factory functions
  createAnalyzer,
  createParser,
  createRuleEngine,
  createLogger,
  createFormatter,
  
  // Convenience functions
  analyze,
  analyzeProject,
  
  // Version
  version: require('../package.json').version,
  
  // Constants
  SEVERITY: {
    CRITICAL: 'CRITICAL',
    HIGH: 'HIGH',
    MEDIUM: 'MEDIUM',
    LOW: 'LOW'
  },
  
  CATEGORIES: {
    PERFORMANCE: 'PERFORMANCE',
    COMPLEXITY: 'COMPLEXITY',
    SECURITY: 'SECURITY',
    MAINTAINABILITY: 'MAINTAINABILITY',
    BEST_PRACTICES: 'BEST_PRACTICES'
  }
};
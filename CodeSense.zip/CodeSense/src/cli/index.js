#!/usr/bin/env node
/**
 * CLI Interface for Code Sense
 */

const { program } = require('commander');
const { readFileSync, existsSync, readdirSync, statSync } = require('fs');
const { resolve, extname, relative } = require('path');
const CodeAnalyzer = require('../core/analyzer.js');
const Logger = require('../utils/logger.js');
const Formatter = require('../utils/formatter.js');
const { version } = require('../../package.json');

// Initialize
const logger = new Logger({ level: 'info', colors: true });
let analyzer = null;

/**
 * Load configuration file
 * @param {string} configPath - Path to config file
 * @returns {Object} Configuration object
 */
function loadConfig(configPath) {
  const defaultConfig = {
    parserOptions: {},
    ruleOptions: {},
    ignorePatterns: ['**/node_modules/**', '**/*.test.js', '**/*.spec.js']
  };

  try {
    if (existsSync(configPath)) {
      const configContent = readFileSync(configPath, 'utf-8');
      const userConfig = JSON.parse(configContent);
      return { ...defaultConfig, ...userConfig };
    }
  } catch (error) {
    logger.warn(`Failed to load config: ${error.message}`);
  }

  return defaultConfig;
}

/**
 * Check if file should be analyzed
 * @param {string} filePath - File path
 * @param {Array} ignorePatterns - Patterns to ignore
 * @returns {boolean} True if file should be analyzed
 */
function shouldAnalyzeFile(filePath, ignorePatterns) {
  // Check extension
  if (!['.js', '.jsx', '.mjs', '.cjs'].includes(extname(filePath))) {
    return false;
  }

  // Check ignore patterns
  const relativePath = relative(process.cwd(), filePath);
  return !ignorePatterns.some(pattern => {
    const regex = new RegExp(pattern.replace(/\*\*/g, '.*').replace(/\*/g, '[^/]*'));
    return regex.test(relativePath);
  });
}

/**
 * Find JavaScript files in directory
 * @param {string} directory - Directory path
 * @param {Array} ignorePatterns - Patterns to ignore
 * @returns {Array} Array of file paths
 */
function findJsFiles(directory, ignorePatterns) {
  const files = [];
  
  function scan(dir) {
    const items = readdirSync(dir);
    
    items.forEach(item => {
      const fullPath = resolve(dir, item);
      
      try {
        const stats = statSync(fullPath);
        
        if (stats.isDirectory()) {
          scan(fullPath);
        } else if (stats.isFile() && shouldAnalyzeFile(fullPath, ignorePatterns)) {
          files.push(fullPath);
        }
      } catch (error) {
        // Skip files we can't access
      }
    });
  }
  
  scan(directory);
  return files;
}

// Setup CLI
program
  .name('codesense')
  .description('Advanced JavaScript static analysis tool')
  .version(version || '1.0.0')
  .option('-c, --config <path>', 'Configuration file path', '.codesenserc.json')
  .option('--no-color', 'Disable colored output')
  .option('-v, --verbose', 'Enable verbose logging')
  .option('-q, --quiet', 'Only show errors');

// Analyze command
program
  .command('analyze <path>')
  .description('Analyze a file or directory')
  .option('-o, --output <format>', 'Output format (human, json, markdown, csv, html)', 'human')
  .option('-f, --format <format>', 'Alias for --output')
  .option('-r, --recursive', 'Analyze directories recursively', true)
  .option('-d, --details', 'Show detailed analysis')
  .option('--fix', 'Attempt to auto-fix issues (experimental)')
  .action(async (path, options) => {
    try {
      // Load configuration
      const configPath = resolve(program.opts().config);
      const config = loadConfig(configPath);
      
      // Setup logger
      logger.level = program.opts().verbose ? 'debug' : program.opts().quiet ? 'error' : 'info';
      logger.useColors = program.opts().color;
      
      // Initialize analyzer
      analyzer = new CodeAnalyzer(config);
      
      const fullPath = resolve(path);
      
      if (!existsSync(fullPath)) {
        logger.error(`Path not found: ${path}`);
        process.exit(1);
      }
      
      const stats = statSync(fullPath);
      const spinner = logger.createSpinner('Initializing analysis...');
      
      if (stats.isFile()) {
        // Analyze single file
        spinner.start().updateMessage('Analyzing file...');
        
        const sourceCode = readFileSync(fullPath, 'utf-8');
        const results = await analyzer.analyzeFile(fullPath, sourceCode);
        
        spinner.stop('Analysis complete!');
        
        // Format output
        const formatter = new Formatter({
          format: options.output || options.format,
          colors: logger.useColors
        });
        
        if (options.output === 'json' || options.output === 'csv' || options.output === 'html') {
          console.log(formatter.format(results));
        } else {
          logger.displayResults(results);
        }
        
        // Exit code based on issues
        const criticalIssues = results.issues.filter(i => i.severity === 'CRITICAL').length;
        process.exit(criticalIssues > 0 ? 1 : 0);
        
      } else if (stats.isDirectory()) {
        // Analyze directory
        spinner.start().updateMessage('Scanning directory...');
        
        const files = findJsFiles(fullPath, config.ignorePatterns);
        
        if (files.length === 0) {
          spinner.stop();
          logger.warn(`No JavaScript files found in: ${path}`);
          process.exit(0);
        }
        
        spinner.updateMessage(`Analyzing ${files.length} files...`);
        
        const allResults = {
          files: [],
          summary: {
            totalFiles: files.length,
            analyzedFiles: 0,
            failedFiles: 0,
            totalIssues: 0,
            averageScore: 0,
            topIssues: []
          },
          timestamp: new Date().toISOString()
        };
        
        let totalScore = 0;
        const issueCounts = {};
        
        // Analyze each file
        for (let i = 0; i < files.length; i++) {
          const file = files[i];
          spinner.updateMessage(`Analyzing ${i + 1}/${files.length}: ${relative(process.cwd(), file)}`);
          
          try {
            const sourceCode = readFileSync(file, 'utf-8');
            const results = await analyzer.analyzeFile(file, sourceCode);
            
            allResults.files.push({
              file: relative(process.cwd(), file),
              score: results.score,
              issueCount: results.issues.length,
              success: results.success
            });
            
            allResults.summary.analyzedFiles++;
            totalScore += results.score;
            allResults.summary.totalIssues += results.issues.length;
            
            // Count issues by type
            results.issues.forEach(issue => {
              const type = issue.type || 'UNKNOWN';
              issueCounts[type] = (issueCounts[type] || 0) + 1;
            });
            
          } catch (error) {
            allResults.files.push({
              file: relative(process.cwd(), file),
              error: error.message,
              success: false
            });
            allResults.summary.failedFiles++;
            logger.debug(`Failed to analyze ${file}: ${error.message}`);
          }
        }
        
        // Calculate summary
        allResults.summary.averageScore = allResults.summary.analyzedFiles > 0 
          ? totalScore / allResults.summary.analyzedFiles 
          : 0;
        
        // Get top 5 issues
        allResults.summary.topIssues = Object.entries(issueCounts)
          .sort((a, b) => b[1] - a[1])
          .slice(0, 5)
          .map(([type, count]) => ({ type, count }));
        
        spinner.stop('Project analysis complete!');
        
        // Display summary
        logger.displayProjectSummary(allResults.summary);
        
        // Save detailed report if requested
        if (options.details) {
          const formatter = new Formatter({ format: 'json' });
          const reportPath = resolve(process.cwd(), 'codesense-report.json');
          require('fs').writeFileSync(reportPath, formatter.format(allResults));
          logger.info(`Detailed report saved to: ${reportPath}`);
        }
        
        // Exit code
        const failedPercentage = (allResults.summary.failedFiles / allResults.summary.totalFiles) * 100;
        process.exit(failedPercentage > 50 ? 1 : 0);
        
      } else {
        spinner.stop();
        logger.error(`Path is not a file or directory: ${path}`);
        process.exit(1);
      }
      
    } catch (error) {
      logger.error('Analysis failed:', error);
      process.exit(1);
    }
  });

// Watch command
program
  .command('watch <directory>')
  .description('Watch directory for changes and analyze automatically')
  .option('-i, --interval <ms>', 'Check interval in milliseconds', '5000')
  .action((directory, options) => {
    logger.info(`Starting watch mode on: ${directory}`);
    logger.info(`Check interval: ${options.interval}ms`);
    logger.info('Press Ctrl+C to stop\n');
    
    // This would be implemented with chokidar or similar
    logger.warn('Watch mode is not yet implemented');
    logger.info('Use "codesense analyze" for static analysis');
  });

// Init command
program
  .command('init')
  .description('Initialize Code Sense configuration file')
  .action(() => {
    const config = {
      "$schema": "./schema.json",
      "parserOptions": {
        "ecmaVersion": "latest",
        "sourceType": "module"
      },
      "rules": {
        "performance": true,
        "complexity": true,
        "maintainability": true,
        "security": true
      },
      "ignorePatterns": [
        "**/node_modules/**",
        "**/*.test.js",
        "**/*.spec.js",
        "dist/**",
        "build/**"
      ],
      "output": {
        "format": "human",
        "colors": true,
        "saveReport": false
      }
    };
    
    const configPath = resolve(process.cwd(), '.codesenserc.json');
    
    if (existsSync(configPath)) {
      logger.warn(`Configuration file already exists: ${configPath}`);
    } else {
      require('fs').writeFileSync(
        configPath, 
        JSON.stringify(config, null, 2)
      );
      logger.success(`Configuration file created: ${configPath}`);
    }
  });

// Rules command
program
  .command('rules')
  .description('List available analysis rules')
  .action(() => {
    const RuleEngine = require('../core/rules.js');
    const rules = new RuleEngine();
    
    console.log('\n' + '='.repeat(60));
    console.log('📜 AVAILABLE ANALYSIS RULES');
    console.log('='.repeat(60));
    
    const categories = {};
    
    rules.rules.forEach(rule => {
      if (!categories[rule.category]) {
        categories[rule.category] = [];
      }
      categories[rule.category].push(rule);
    });
    
    Object.entries(categories).forEach(([category, categoryRules]) => {
      console.log(`\n📂 ${category}`);
      console.log('─'.repeat(40));
      
      categoryRules.forEach(rule => {
        let severityIcon = '○';
        switch (rule.severity) {
          case 'CRITICAL': severityIcon = '🔴'; break;
          case 'HIGH': severityIcon = '🟠'; break;
          case 'MEDIUM': severityIcon = '🟡'; break;
          case 'LOW': severityIcon = '🔵'; break;
        }
        
        console.log(`  ${severityIcon} ${rule.name}`);
        console.log(`     ID: ${rule.id}`);
        console.log(`     ${rule.message}`);
      });
    });
    
    console.log('\n' + '='.repeat(60));
  });

// Handle unknown commands
program.on('command:*', () => {
  logger.error(`Invalid command: ${program.args.join(' ')}`);
  console.log();
  program.help();
});

// Show help if no arguments
if (process.argv.length <= 2) {
  program.help();
}

// Parse arguments
program.parse(process.argv);
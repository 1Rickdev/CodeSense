/**
 * Example file for Code Sense analysis
 * This file contains various code patterns for testing
 */

// ===== PERFORMANCE PATTERNS =====

// 1. Nested loops (performance issue)
function calculateMatrixSum(matrix) {
  let total = 0;
  
  // Triple nested loop - O(n³) complexity
  for (let i = 0; i < matrix.length; i++) {
    for (let j = 0; j < matrix[i].length; j++) {
      for (let k = 0; k < matrix[i][j].length; k++) {
        total += matrix[i][j][k];
      }
    }
  }
  
  return total;
}

// 2. Sequential async operations
async function fetchUserData(userId) {
  // Sequential awaits - could be parallelized
  const profile = await fetch(`/api/users/${userId}`);
  const orders = await fetch(`/api/users/${userId}/orders`);
  const settings = await fetch(`/api/users/${userId}/settings`);
  const history = await fetch(`/api/users/${userId}/history`);
  
  return {
    profile: await profile.json(),
    orders: await orders.json(),
    settings: await settings.json(),
    history: await history.json()
  };
}

// ===== COMPLEXITY PATTERNS =====

// 3. High cyclomatic complexity
function calculateShippingCost(order, user, promo) {
  if (user.isPremium) {
    if (order.total > 100) {
      return 0;
    } else if (order.total > 50) {
      if (promo && promo.isValid) {
        return 2.99;
      } else {
        return 4.99;
      }
    } else {
      return 9.99;
    }
  } else if (user.isMember) {
    if (order.total > 75) {
      return 5.99;
    } else {
      return 7.99;
    }
  } else {
    if (order.total > 100) {
      return 8.99;
    } else if (order.total > 50) {
      return 12.99;
    } else {
      return 15.99;
    }
  }
}

// 4. Long function
function processOrder(order) {
  // Validate order
  if (!order || !order.items || order.items.length === 0) {
    throw new Error('Invalid order');
  }
  
  // Calculate total
  let subtotal = 0;
  for (let i = 0; i < order.items.length; i++) {
    const item = order.items[i];
    subtotal += item.price * item.quantity;
    
    // Apply item-level discounts
    if (item.discount) {
      subtotal -= item.discount;
    }
  }
  
  // Apply order-level discounts
  if (order.coupon) {
    if (order.coupon.type === 'percentage') {
      subtotal -= subtotal * (order.coupon.value / 100);
    } else if (order.coupon.type === 'fixed') {
      subtotal -= order.coupon.value;
    }
  }
  
  // Calculate tax
  let tax = 0;
  if (order.shippingAddress.state === 'CA') {
    tax = subtotal * 0.0825;
  } else if (order.shippingAddress.state === 'NY') {
    tax = subtotal * 0.08875;
  } else if (order.shippingAddress.state === 'TX') {
    tax = subtotal * 0.0625;
  } else {
    tax = subtotal * 0.06;
  }
  
  // Calculate shipping
  let shipping = 0;
  if (order.shippingMethod === 'express') {
    shipping = 24.99;
  } else if (order.shippingMethod === 'standard') {
    shipping = 9.99;
  } else if (order.shippingMethod === 'free') {
    shipping = 0;
  }
  
  // Final total
  const total = subtotal + tax + shipping;
  
  // Log for analytics
  console.log(`Order processed: ${order.id}`);
  console.log(`Subtotal: $${subtotal.toFixed(2)}`);
  console.log(`Tax: $${tax.toFixed(2)}`);
  console.log(`Shipping: $${shipping.toFixed(2)}`);
  console.log(`Total: $${total.toFixed(2)}`);
  
  // Update inventory
  order.items.forEach(item => {
    updateInventory(item.productId, item.quantity);
  });
  
  // Send notifications
  sendOrderConfirmation(order.email, total);
  
  // Return result
  return {
    success: true,
    orderId: order.id,
    total: total,
    breakdown: {
      subtotal,
      tax,
      shipping
    }
  };
}

// ===== SECURITY PATTERNS =====

// 5. Potential security issues
function processUserInput(input) {
  // Using eval - security risk
  const result = eval(input);
  
  // Setting innerHTML - XSS risk
  document.getElementById('output').innerHTML = input;
  
  // Fetch without validation
  fetch(input);
  
  return result;
}

// ===== BEST PRACTICES =====

// 6. Using var instead of let/const
var globalCounter = 0;

function incrementCounter() {
  var localVar = 10;
  globalCounter += localVar;
  return globalCounter;
}

// 7. Missing error handling
async function loadData(url) {
  const response = fetch(url);
  const data = await response;
  return data.json();
}

// ===== GOOD PATTERNS =====

// 8. Well-structured code
class ShoppingCart {
  constructor() {
    this.items = [];
    this.total = 0;
  }

  addItem(item) {
    this.items.push(item);
    this.calculateTotal();
  }

  removeItem(itemId) {
    this.items = this.items.filter(item => item.id !== itemId);
    this.calculateTotal();
  }

  calculateTotal() {
    this.total = this.items.reduce((sum, item) => sum + item.price, 0);
  }

  async checkout() {
    try {
      const response = await fetch('/api/checkout', {
        method: 'POST',
        body: JSON.stringify({ items: this.items, total: this.total })
      });
      
      if (!response.ok) {
        throw new Error('Checkout failed');
      }
      
      return await response.json();
    } catch (error) {
      console.error('Checkout error:', error);
      throw error;
    }
  }
}

// Helper functions
function updateInventory(productId, quantity) {
  // Implementation
}

function sendOrderConfirmation(email, total) {
  // Implementation
}

// Export for testing
module.exports = {
  calculateMatrixSum,
  fetchUserData,
  calculateShippingCost,
  processOrder,
  processUserInput,
  incrementCounter,
  loadData,
  ShoppingCart
};